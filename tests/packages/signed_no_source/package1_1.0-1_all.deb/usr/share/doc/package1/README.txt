A stupid package, almost empty.
